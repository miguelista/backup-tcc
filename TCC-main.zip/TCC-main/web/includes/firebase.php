<!DOCTYPE html>
<html lang="pt-br">

<head>

</head>

<body>
    <script type="module">
        // Import the functions you need from the SDKs you need
        import {
            initializeApp
        } from "https://www.gstatic.com/firebasejs/9.13.0/firebase-app.js";
        // TODO: Add SDKs for Firebase products that you want to use
        // https://firebase.google.com/docs/web/setup#available-libraries

        // Your web app's Firebase configuration
        const firebaseConfig = {
            apiKey: "AIzaSyDcQ2jBuo5_x9a5FOFVTGfwL5MnChD95hE",
            authDomain: "biblioteca-lino-de-matto-9965d.firebaseapp.com",
            projectId: "biblioteca-lino-de-matto-9965d",
            storageBucket: "biblioteca-lino-de-matto-9965d.appspot.com",
            messagingSenderId: "522797853479",
            appId: "1:522797853479:web:0032dd6b216f49edac5702"
        };

        // Initialize Firebase
        const app = initializeApp(firebaseConfig);
        console.dir('Alexandre, Bruna, Matheus, Miguel e Tiago')
        console.dir('Esse console está funcioando atraveis da implementação do Firebase')
    </script>
</body>

</html>