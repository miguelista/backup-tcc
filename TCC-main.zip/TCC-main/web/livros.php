<?php
//include('protect.php');
?>

<?php
//HEADER
include 'includes/header.php';
//NAV-BAR
include 'includes/nav-bar.php';
?>
<title>Biblioteca Lino de Matos - Livros</title>

<body>
  <?php
  //PRELOARD
  include 'includes/preloard.php';
  ?>

  <?php
  //FOOTER
  include 'includes/footer.php';
  ?>
</body>

</html>