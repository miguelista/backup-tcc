<?php
//include('protect.php');
?>

<?php
//HEADER
include 'includes/header.php';
//NAV-BAR
include 'includes/nav-bar.php';
?>
<title>Biblioteca Lino de Mattos - Sobre a Biblioteca </title>

<body>
  <?php
  //PRELOARD
  include 'includes/preloard.php';
  ?>
  <hr>
  <main>
    <div class="container-noticias">
      <div class="grid-noticias1">
        <img src="img\Bibliotecas2.jpg" alt="">


      </div>
      <div class="grid-noticias2">
        <img src="img\livros1.jpg" alt="">
        <h3>Lorem ipsum</h3>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quo dolor nisi itaque quos autem, recusandae quam nostrum ratione vel sunt! Rem, eveniet ratione quasi quidem a vitae nulla accusantium earum.</p>
      </div>
      <div class="grid-noticias3">
        <img src="img\livros1.jpg" alt="">
        <h3>Lorem ipsum</h3>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Magni nobis earum deleniti libero non quibusdam obcaecati tempora eius soluta repellat! Dolore fugiat officia ipsa culpa in non unde id corrupti.</p>
      </div>
      <div class="grid-noticias4">
        <img src="img\livros1.jpg" alt="">
        <h3>Lorem ipsum</h3>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Atque ab aperiam, consectetur debitis provident delectus fugit fugiat mollitia laborum facilis voluptates. Quam labore beatae soluta itaque iure possimus atque ratione?</p>
      </div>
      <div class="grid-noticias5">
        <img src="img\livros1.jpg" alt="">
        <div class="noticias-fim">
          <h3>Lorem ipsum</h3>
          <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis omnis sed voluptatum. Quis nam dolorum est iste quidem, vero veritatis excepturi. Velit dolore natus molestias? Vitae quaerat eius dignissimos temporibus. Lorem ipsum dolor sit amet consectetur adipisicing elit. Ab at quisquam non accusamus, laborum rem deserunt distinctio molestiae doloremque molestias suscipit animi quo saepe! Similique incidunt asperiores eius id praesentium.
            Minima nostrum rerum doloremque laudantium dolores voluptate asperiores esse, vitae atque culpa nesciunt non! Omnis repudiandae nulla, error vel quae aliquam libero vitae autem ipsa beatae! At sunt harum ipsam. Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatum mollitia ipsa quod doloribus ex itaque blanditiis animi eaque eius dignissimos! Corrupti totam repellendus itaque suscipit fuga nam, quos architecto nobis.
            Esse, similique dolorum.</p>
        </div>
      </div>
    </div>
  </main>
  <?php
  //FOOTER
  include 'includes/footer.php';
  ?>
</body>

</html>